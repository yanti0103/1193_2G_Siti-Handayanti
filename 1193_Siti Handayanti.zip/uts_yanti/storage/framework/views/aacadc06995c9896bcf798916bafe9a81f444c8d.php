

<?php $__env->startSection('title', 'About'); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
        <div class="row">
            <div class="col-10">
                <h1 class="mt-4">"Keunggulan parfum Oriflame"</h1>
            <table>
                <h2>Oriflame telah berdiri sejak 1967. Sejak saat itu, Oriflame terus melalukan riset dan pengembangan terhadap setiap produk-produknya. Bahkan, Oriflame juga bekerja sama dengan master perfumers Olivier Cresp, Maurice Roucel, dan Nathalie Lorson. Ketiga orang tersebut adalah para peracik wewangian terbaik di dunia.


Selain itu, untuk menjaga kualitas setiap parfumnya, Oriflame selalu melakukan pengujian terhadap tingkat kualitas aroma. Oleh karena itu, tidak heran jika parfum Oriflame diganjar berbagai penghargaan. Salah satunya adalah penghargaan di bidang wewangian bernama Lifestyle Femme. Penghargaan ini bisa dikatakan setara dengan penghargaan piala Oscar.</h2>
            </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web Laravel\uts_yanti\resources\views/about.blade.php ENDPATH**/ ?>