

<?php $__env->startSection('title', 'TUGAS WEB'); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
        <div class="row">
            <div class="center">
            <div class="col-11" >
                <h1 class="mt-6">Riwayat Hidup</h1>
                <a href="https://ibb.co/KzhzHVy"><img src="https://i.ibb.co/KzhzHVy/foto-divaa.jpg" alt="foto-divaa" border="0"></a>
                <table>
                <h2>Biodata</h2>
                <tr>
                    <td>Nama</td>
                    <td>:</td>
                    <td>Diva Dwi Febriyanti</td>
                </tr>
                <tr>
                    <td>Tempat, Tanggal Lahir</td>
                    <td>:</td>
                    <td>Banyuwangi, 27 Februari 2003</td>
                </tr>
                <tr>
                    <td>Alamat</td>
                    <td>:</td>
                    <td>Blambangan,Muncar</td>
                </tr>
                <tr>
                    <td>Jenis Kelamin</td>
                    <td>:</td>
                    <td>Perempuan</td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td>:</td>
                    <td>divafebrynti5@gmail.com</td>
                </tr>
            </table>

            </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\WEBAPLICATION\tugas-web\resources\views/index.blade.php ENDPATH**/ ?>