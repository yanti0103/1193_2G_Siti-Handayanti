

<?php $__env->startSection('title', 'Daftar Buku'); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
        <div class="row">
            <div class="col-10">
                <h1 class="mt-4">Daftar Buku</h1>

               <table class="table">
                <thead class="thead-dark">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Judul Buku</th>
                    <th scope="col">Penulis</th>
                    <th scope="col">Penerbit</th>
                    <th scope="col">Tahun Rilis</th>
                    <th scope="col">Aksi</th>
                </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row">1</th>
                        <td>Laskar Pelangi</td>
                        <td>Andrea Hirata</td>
                        <td>Bentang Pustaka</td>
                        <td>2005</td>
                        <td>
                            <a href="" class="badge badge-success">edit</a>
                            <a href="" class="badge badge-danger">delete</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
               </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\WEBAPLICATION\tugas-web\resources\views/buku/index.blade.php ENDPATH**/ ?>