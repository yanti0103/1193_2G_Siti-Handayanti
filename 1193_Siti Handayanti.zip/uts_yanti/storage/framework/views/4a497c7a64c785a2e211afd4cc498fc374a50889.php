

<?php $__env->startSection('title', 'TUGAS WEB'); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
        <div class="row">
            <div class="center">
            <div class="col-11" >
                <h1 class="mt-6"></h1>
                <table>
                <h2>Barang</h2>
                <td>Rekomendasi Parfum Oriflame Terbaik untuk Wanita (Terbaru Tahun 2022)</td>
                <a href="https://imgbb.com/"><img src="https://i.ibb.co/T1SfCQ9/parfum.jpg" alt="parfum" border="0"></a>
                <tr>
                    
                    
                    <td>Oriflame adalah perusahaan kecantikan yang bergerak dalam perancangan, pengembangan, dan produksi produk. Salah satu jenis produk yang dihasilkan Oriflame adalah parfum. Parfum-parfum Oriflame terdiri dari berbagai lini merek, seperti Divine, Eclat, dan Giordani Gold. Untuk Anda para wanita, Oriflame memiliki parfum yang bagus dengan aroma yang memikat hati dan tahan lama.
                    Dari banyaknya pilihan yang ditawarkan, kami akan membantu Anda menemukan parfum Oriflame yang wanginya enak. Silakan simak ulasan lengkap mengenai parfum Oriflame, mulai dari cara pemilihannya sampai rekomendasi parfum terbaik yang patut Anda miliki.
                    </td>
                </tr>
                <tr>
                    
                </tr>
            </table>

            </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web Laravel\uts_yanti\resources\views/index.blade.php ENDPATH**/ ?>