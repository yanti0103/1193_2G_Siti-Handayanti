

<?php $__env->startSection('title', 'About'); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
        <div class="row">
            <div class="col-10">
                <h1 class="mt-4">"Banyaklah membaca, sampai bukumu terasa seperti makanan pokok."</h1>
            <table>
                <h2>Kata mutiara pendidikan seringkali menjadikan seseorang termotivasi untuk lebih semangat belajar, baik di sekolah, perguruan tinggi, maupun swasta.

Kata mutiara tentang pendidikan mengingatkan kembali bahwa tanpa pendidikan, cita-cita akan lebih sulit tergambarkan. Seseorang juga akan lebih sulit meraih kedewasaan. Sebab dengan pendidikan, pikiran akan menjadi lebih berkembang, terbuka, dan mampu menerima keberagaman.
Menjadi orang yang berpendidikan memang tidak mudah. Harus rela mengorbankan waktu, tenaga, dan biaya yang tidak sedikit. Tanpa tekad yang kuat, mungkin upaya menjadi orang yang berpendidikan tidak akan didapatkan.

Maka dari itu, semakin bertekad untuk terus menempuh pendidikan setinggi-tingginya.

Selain mampu menguatkan tekad, kata mutiara pendidikan ini juga akan membuat segala rintangan yang menghadang bisa dilalui. Seperti ketika merasa sangat lelah, bosan, dan ingin menyudahi pendidikan di tengah jalan.</h2>
            </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\WEBAPLICATION\tugas-web\resources\views/about.blade.php ENDPATH**/ ?>